
    window.geniallyElearningPresetData = {
      passingPercentage: 100,
      dataGeniallyOffline: window.dataGeniallyOffline
    };
      